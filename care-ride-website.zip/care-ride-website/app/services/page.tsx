import type {Metadata} from "next";
import {services} from "@/lib/content";
import {PageIntro,ServiceCard,Callout} from "@/components/site-content";
export const metadata:Metadata={title:"Transportation services"};
export default function Services(){return <><PageIntro eyebrow="OUR SERVICES" title="Care has a destination. We help you get there." description="Explore transportation for appointments, recurring care, and other approved trips. Select a service to learn what to arrange before you ride."/><section className="section shell"><div className="service-grid">{services.map((service,i)=><ServiceCard key={service.slug} service={service} number={i+1}/>)}</div><p className="section-note">Services depend on trip approval, vehicle suitability, and availability. Confirm your specific arrangements with MAS or your plan and Care Ride dispatch.</p></section><Callout/></>;}
