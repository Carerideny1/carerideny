import type {Metadata} from "next";

import {notFound} from "next/navigation";
import {ArrowLeft,ArrowRight,Check,Phone} from "lucide-react";
import {services} from "@/lib/content";
import {Callout,ServiceIcon} from "@/components/site-content";
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;return {title:services.find(s=>s.slug===slug)?.title||"Service not found"};}
export default async function ServiceDetail({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const service=services.find(s=>s.slug===slug);if(!service)notFound();return <><section className="service-detail shell section"><a className="back-link" href="/services"><ArrowLeft size={17}/>All services</a><div className="detail-grid"><div><span className="service-icon large"><ServiceIcon kind={service.icon}/></span><p className="eyebrow">CARE RIDE SERVICES</p><h1>{service.title}</h1><p className="detail-lede">{service.detail}</p><ul className="detail-list">{service.examples.map(x=><li key={x}><Check size={19}/>{x}</li>)}</ul></div><aside className="detail-next"><p className="eyebrow">BEFORE YOU RIDE</p><h2>Let’s get the<br/>details right.</h2><p>{service.note}</p><a className="btn red" href="/how-to-book">How to arrange a ride <ArrowRight size={17}/></a><a className="text-link" href="tel:+16319483362"><Phone size={17}/>Questions? Call dispatch</a></aside></div></section><Callout/></>;}
