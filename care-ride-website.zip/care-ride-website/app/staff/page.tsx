import type {Metadata} from "next";
import {requireChatGPTUser,chatGPTSignOutPath} from "@/app/chatgpt-auth";
import {isStaffEmail} from "@/lib/staff";
import {PageIntro} from "@/components/site-content";
import {StaffInbox} from "@/components/staff-inbox";
export const dynamic="force-dynamic";
export const metadata:Metadata={title:"Staff callback inbox",robots:{index:false,follow:false}};
export default async function Staff(){const user=await requireChatGPTUser("/staff");if(!isStaffEmail(user.email))return <><PageIntro eyebrow="STAFF ACCESS" title="This inbox is restricted." description="Sign in with the authorized website owner’s account to review callback requests."/><section className="shell section"><a className="btn navy" href={chatGPTSignOutPath("/staff")} target="_top">Use another account</a></section></>;return <><PageIntro eyebrow="CARE RIDE · STAFF" title="A helpful follow-up starts here." description="Review callback requests and keep track of who has been contacted."/><section className="shell section"><StaffInbox/></section></>;}
