import type {Metadata} from "next";
import {MapPin,ArrowRight} from "lucide-react";
import {PageIntro,Callout} from "@/components/site-content";
import {CoverageMap} from "@/components/coverage-map";
export const metadata:Metadata={title:"Long Island & NYC service area",description:"Explore Care Ride transportation coverage across Suffolk, Nassau, Queens, Brooklyn, Manhattan, and the Bronx."};
export default function ServiceArea(){return <><PageIntro eyebrow="LONG ISLAND & NEW YORK CITY" title="Across the Island. Into the city." description="From our home base in Shirley, we serve all of Long Island, plus Manhattan, Queens, Brooklyn, and the Bronx. Select an area to explore."/><section className="shell section coverage-page"><CoverageMap/><div className="coverage-trip-help" data-reveal><MapPin size={32}/><div><h2>Your trip starts with a conversation.</h2><p>Tell dispatch your pickup location, appointment destination, and any assistance needs. We’ll help you confirm the next step for your trip.</p></div><a className="btn navy" href="/contact">Talk with our team <ArrowRight size={18}/></a></div></section><Callout/></>;}
