"use client";

import {useEffect} from "react";
import {CarFront} from "lucide-react";

export function LoadingLogo(){
  return <div className="loading-brand"><span className="loading-logo-crop"><img src="/care-ride-logo.png" width="200" height="150" alt="Care Ride Transportation"/></span><div className="loading-road" aria-hidden="true"><CarFront size={25}/></div><p>Your ride to care.</p></div>;
}

export function SiteMotion(){
  useEffect(()=>{
    const root=document.documentElement;
    let fallback:ReturnType<typeof setTimeout>;
    const reset=()=>{delete root.dataset.navigating;clearTimeout(fallback);};
    const onClick=(event:MouseEvent)=>{
      if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
      const link=event.target instanceof Element?event.target.closest<HTMLAnchorElement>("a[href]"):null;
      if(!link||link.hasAttribute("download")||(link.target&&link.target!=="_self"))return;
      const destination=new URL(link.href,location.href);
      if(destination.origin!==location.origin||!/^https?:$/.test(destination.protocol))return;
      clearTimeout(fallback);
      if(destination.pathname===location.pathname&&destination.search===location.search){
        if(destination.hash&&destination.hash!==location.hash){root.dataset.navigating="section";fallback=setTimeout(reset,650);}
        return;
      }
      // Keep native full-page navigation: the animation never intercepts a link.
      root.dataset.navigating="page";
      fallback=setTimeout(reset,9000);
    };
    document.addEventListener("click",onClick);
    window.addEventListener("pageshow",reset);
    return()=>{reset();document.removeEventListener("click",onClick);window.removeEventListener("pageshow",reset);};
  },[]);
  return <div className="page-loader" role="status" aria-label="Loading Care Ride page"><LoadingLogo/></div>;
}
