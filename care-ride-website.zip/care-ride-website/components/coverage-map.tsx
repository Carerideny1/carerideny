"use client";

import {useState} from "react";
import {ArrowRight,ChevronRight,MapPin,Phone,Scan,ZoomIn} from "lucide-react";
import {RadioGroup,RadioGroupItem} from "@/components/ui/radio-group";
import {countyShapes,shirleyPoint} from "@/lib/coverage-geometry";

const regions=[
  {id:"suffolk",name:"Suffolk County",group:"Long Island",title:"From our home base to the East End.",description:"Based in Shirley, we serve communities throughout Suffolk County, with connections across Long Island and into New York City.",places:"Shirley · Brookhaven · Islip · Huntington · Riverhead · The East End"},
  {id:"nassau",name:"Nassau County",group:"Long Island",title:"Care across Nassau County.",description:"Transportation throughout Nassau County, with trips to and from Suffolk County and the NYC boroughs we serve.",places:"Hempstead · Garden City · Mineola · Long Beach · Glen Cove"},
  {id:"queens",name:"Queens",group:"New York City",title:"Your connection to care in Queens.",description:"We serve Queens for non-emergency medical transportation, including connections with Long Island and our other service areas.",places:"Queens pickups and appointment destinations"},
  {id:"brooklyn",name:"Brooklyn",group:"New York City",title:"Getting you to care in Brooklyn.",description:"Brooklyn is part of our service area for scheduled non-emergency trips, including appointments beyond your own neighborhood.",places:"Brooklyn pickups and appointment destinations"},
  {id:"manhattan",name:"Manhattan",group:"New York City",title:"From Long Island into Manhattan.",description:"We serve Manhattan for scheduled non-emergency medical transportation. Plan your pickup, appointment, and return trip in advance.",places:"Manhattan pickups and appointment destinations"},
  {id:"bronx",name:"The Bronx",group:"New York City",title:"A connection to care in the Bronx.",description:"The Bronx is included in our service area, connecting passengers with their scheduled appointments and approved destinations.",places:"Bronx pickups and appointment destinations"},
];

export function CoverageMap({compact=false}:{compact?:boolean}){
  const [selected,setSelected]=useState("suffolk");
  const [zoom,setZoom]=useState(false);
  const region=regions.find(item=>item.id===selected)!;
  const shape=countyShapes.find(item=>item.id===selected)!;
  const [hubX,hubY]=shirleyPoint;
  const [endX,endY]=shape.center;
  const choose=(id:string)=>{setSelected(id);if(id==="suffolk"||id==="nassau")setZoom(false);};
  return <div className={"coverage-explorer "+(compact?"compact":"")}>
    <div className="coverage-map-panel">
      <div className="coverage-map-toolbar"><span><MapPin size={17}/> Long Island & NYC</span><div><button type="button" onClick={()=>setZoom(false)} aria-pressed={!zoom}><Scan size={16}/>Full area</button><button type="button" onClick={()=>setZoom(true)} aria-pressed={zoom}><ZoomIn size={16}/>NYC close-up</button></div></div>
      <svg className={"coverage-svg "+(zoom?"zoomed":"")} viewBox={zoom?"35 220 245 240":"0 0 1000 490"} aria-label="Interactive service area map. Select a county or borough." role="group">
        <title>Care Ride serves Suffolk, Nassau, Queens, Brooklyn, Manhattan, and the Bronx</title>
        <defs><pattern id={compact?"map-grid-home":"map-grid-area"} width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="#c8dce5" strokeWidth=".5"/></pattern></defs>
        <rect x="-50" y="-100" width="1300" height="900" fill={"url(#"+(compact?"map-grid-home":"map-grid-area")+")"}/>
        {countyShapes.map(county=>{const item=regions.find(r=>r.id===county.id);return item?<path key={county.id} d={county.path} fillRule="evenodd" className={"map-region "+(selected===county.id?"selected":"")} role="button" tabIndex={0} aria-label={"View "+item.name+" coverage"} aria-pressed={selected===county.id} onClick={()=>choose(county.id)} onKeyDown={event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();choose(county.id);}}}/>:<path key={county.id} d={county.path} fillRule="evenodd" className="map-context" aria-hidden="true"/>;})}
        {!zoom&&<g className="map-place-labels" aria-hidden="true"><text x="610" y="240" className="major">SUFFOLK COUNTY</text><text x="257" y="310">NASSAU</text><text x="460" y="124" className="water">LONG ISLAND SOUND</text><text x="670" y="410" className="water">ATLANTIC OCEAN</text><text x="141" y="240" className="city-label">NEW YORK CITY</text></g>}
        {zoom&&<g className="map-city-labels" aria-hidden="true"><text x="143" y="365">Queens</text><text x="85" y="409">Brooklyn</text><text x="80" y="310" transform="rotate(-57 80 310)">Manhattan</text><text x="130" y="263">Bronx</text><text x="245" y="295">Nassau</text></g>}
        {!zoom&&<g className="map-connection" aria-hidden="true" key={selected}><path d={`M${hubX},${hubY} Q${(hubX+endX)/2},${Math.min(hubY,endY)-65} ${endX},${endY}`} className="map-route"/><circle cx={endX} cy={endY} r="5" className="map-destination"/><circle cx={hubX} cy={hubY} r="14" className="map-hub-ring"/><circle cx={hubX} cy={hubY} r="6" className="map-hub"/><rect x={hubX-53} y={hubY+16} width="106" height="44" rx="5"/><text x={hubX} y={hubY+34}>Shirley</text><text x={hubX} y={hubY+49} className="hub-subtitle">OUR HOME BASE</text></g>}
      </svg>
      <div className="map-legend"><span><i/>Service area</span><span><i/>Selected area</span><span className="map-hint">Tap a region to explore</span></div>
      <div className="map-attribution"><a href="https://gis.ny.gov/civil-boundaries" target="_blank" rel="noreferrer">Map boundaries: NYS ITS</a><span>Connections shown are illustrative.</span></div>
    </div>
    <div className="coverage-details"><p className="eyebrow">SELECT YOUR AREA</p><RadioGroup value={selected} onValueChange={choose} className="coverage-region-list" aria-label="Service regions">{regions.map(item=><label key={item.id} className={selected===item.id?"selected":""}><RadioGroupItem value={item.id}/><span>{item.name}</span><ChevronRight size={15}/></label>)}</RadioGroup><div className="coverage-region-detail" aria-live="polite" aria-atomic="true"><span className="coverage-region-group">{region.group} · In our service area</span><h3>{region.title}</h3><p>{region.description}</p>{!compact&&<p className="coverage-places">{region.places}</p>}</div><a className="text-link" href={compact?"/service-area":"tel:+16319483362"}>{compact?"Explore our service area":"Confirm your trip with dispatch"}{compact?<ArrowRight size={18}/>:<Phone size={17}/>}</a></div>
    <p className="coverage-note">We serve all of Long Island, plus Manhattan, Queens, Brooklyn, and the Bronx. Individual trips are subject to scheduling, vehicle availability, and any required authorization.</p>
  </div>;
}
