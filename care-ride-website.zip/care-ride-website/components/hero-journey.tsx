"use client";

import {useEffect,useState} from "react";
import {Pause,Play,ArrowUpRight} from "lucide-react";

const scenes=[
  {image:"/care-ride-journey.png",label:"Along the way",text:"Everyday vehicles. A thoughtful journey.",alt:"AI-created scene of a Care Ride branded sedan traveling on a Long Island road"},
  {image:"/care-ride-pickup.png",label:"At your side",text:"From your pickup to your appointment.",alt:"AI-created scene of a driver assisting an older passenger beside a Care Ride branded SUV"},
];

export function HeroJourney(){
  const [scene,setScene]=useState(0);
  const [paused,setPaused]=useState(false);
  const [reduced,setReduced]=useState(true);
  useEffect(()=>{const media=window.matchMedia("(prefers-reduced-motion: reduce)");const update=()=>setReduced(media.matches);update();media.addEventListener("change",update);return()=>media.removeEventListener("change",update);},[]);
  useEffect(()=>{if(paused||reduced)return;const timer=setInterval(()=>setScene(value=>(value+1)%scenes.length),7000);return()=>clearInterval(timer);},[paused,reduced]);
  const still=paused||reduced;
  return <div className="hero-journey" data-paused={still} aria-label="Care Ride journey scenes" aria-roledescription="carousel">
    <div className="journey-frames">{scenes.map((item,index)=><div key={item.image} className={"journey-frame "+(index===scene?"active":"")} aria-hidden={index!==scene}><img src={item.image} alt={item.alt} width="1536" height="1024" fetchPriority={index===0?"high":"auto"} decoding="async"/></div>)}</div>
    <span className="journey-tag">SEDAN & SUV TRANSPORTATION</span>
    <div className="journey-bottom"><div className="journey-caption"><span>{scenes[scene].label}</span><strong>{scenes[scene].text}</strong></div><div className="journey-controls"><div className="scene-tabs" aria-label="Choose a scene">{scenes.map((item,index)=><button type="button" key={item.image} onClick={()=>{setScene(index);setPaused(true);}} aria-label={"Show scene: "+item.label} aria-pressed={scene===index}><span/></button>)}</div>{!reduced&&<button className="journey-pause" type="button" aria-label={paused?"Play vehicle scenes":"Pause vehicle scenes"} onClick={()=>setPaused(value=>!value)}>{paused?<Play size={17}/>:<Pause size={17}/>}</button>}</div></div>
    <span className="journey-disclosure">AI-created scenes</span>
    <a href="#coverage" className="journey-map-link">Explore our coverage <ArrowUpRight size={16}/></a>
  </div>;
}
