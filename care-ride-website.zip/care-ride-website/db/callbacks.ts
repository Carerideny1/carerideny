import {env} from "cloudflare:workers";
export function callbackDb():D1Database{if(!env.DB)throw new Error("Callback storage unavailable");return env.DB;}
